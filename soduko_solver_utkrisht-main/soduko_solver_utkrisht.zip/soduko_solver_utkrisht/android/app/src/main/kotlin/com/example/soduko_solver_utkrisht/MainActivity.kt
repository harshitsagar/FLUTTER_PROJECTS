package com.example.soduko_solver_utkrisht

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
